from django.apps import AppConfig
from django.contrib.auth.models import User

class MyappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'myapp'

    def ready(self):
        # Create default user if not exists
        default_password = "Arisstotle_fc"
        default_username = "user"  # pwede palitan
        if not User.objects.filter(username=default_username).exists():
            User.objects.create_user(username=default_username, password=default_password)
