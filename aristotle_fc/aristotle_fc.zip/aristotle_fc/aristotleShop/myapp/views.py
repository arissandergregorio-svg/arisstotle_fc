from django.shortcuts import render, redirect, get_object_or_404
from .models import Product, Sale
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
# Login page
def user_login(request):
    if request.method == "POST":
        username = request.POST.get("username")
        password = request.POST.get("password")
        user = authenticate(request, username=username, password=password)
        if user:
            login(request, user)
            return redirect("chicken_sale")
        else:
            return render(request, "myapp/login.html", {"error": "Invalid credentials"})
    return render(request, "myapp/login.html")

# Logout
def user_logout(request):
    logout(request)
    return redirect("login")

# Chicken Sale page
@login_required(login_url='/login/')
def chicken_sale(request):
    # Default products
    default_products = [
        ("Whole Chicken", 230),
        ("Half Chicken", 110),
        ("Legs", 55),
        ("Breast", 50),
        ("Neck", 10),
    ]
    for name, price in default_products:
        Product.objects.get_or_create(name=name, defaults={"price": price})

    products = Product.objects.all()
    sales = Sale.objects.all()

    if request.method == "POST":
        action = request.POST.get("action")  # "add", "update", "delete"
        product_id = request.POST.get("product_id")
        name = request.POST.get("name")
        price = request.POST.get("price")
        quantity = request.POST.get("quantity")

        # Convert
        price = float(price) if price else 0.0
        quantity = int(quantity) if quantity else 0

        # ADD Product
        if action == "add" and name:
            product, created = Product.objects.get_or_create(name=name, defaults={"price": price})
            if not created:
                product.price = price
                product.save()

        # UPDATE Product
        elif action == "update" and product_id:
            product = get_object_or_404(Product, id=int(product_id))
            if name:
                product.name = name
            product.price = price
            product.save()
            sale, _ = Sale.objects.get_or_create(product=product)
            sale.quantity = quantity
            sale.save()

        # DELETE Product
        elif action == "delete" and product_id:
            product = get_object_or_404(Product, id=int(product_id))
            product.delete()

        return redirect("chicken_sale")

    total_sale = sum(sale.total for sale in sales)
    context = {
        "products": products,
        "sales": sales,
        "total_sale": total_sale,
    }
    return render(request, "myapp/chicken_sale.html", context)
